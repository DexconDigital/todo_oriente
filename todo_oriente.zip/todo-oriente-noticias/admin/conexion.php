<?php

function Conect()
{
    # code...

    mysqli_connect("50.62.209.73:3306","todooriente_user","nosequeponer123","TodoOriente_noticias");

    return $echo;
}

?>


