configure({
  configs: [
    './test.js'
  ],
  sources: [

  ]
});
